#!/bin/sh
# Used to clean up some non essential folders to make the ws container

rm -rf build
rm -rf third_party/zlib
rm -rf third_party/mbedtls
